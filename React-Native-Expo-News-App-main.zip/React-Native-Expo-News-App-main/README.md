# React-Native-Expo-News-App
Cryptocurrency news app in react native expo. Projects for native beginners

[Full Documentation of the code is here](https://ninza7.medium.com/cryptocurrency-news-app-using-react-native-expo-and-newsapi-c3f96ca3be20)

[Video Tutorial](https://youtu.be/yUEXP2ED2zg)
